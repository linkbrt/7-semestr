package com.example.lr2

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.AppCompatEditText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.Typeface
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.lr2.ui.theme.LR2Theme

class MainActivity : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    private var textItems = arrayOf<TextView>()

    private val startForResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK)
        {
            applySettings()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(R.style.AppTheme)
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE)
        val settingsButton: Button = findViewById(R.id.settings_button)
        settingsButton.setOnClickListener { openSettings() }

        val hoursEditText = findViewById<EditText>(R.id.hoursEditText)
        val minutesEditText = findViewById<EditText>(R.id.minutesEditText)
        val resultTextView = findViewById<TextView>(R.id.resultTextView)
        val calculateButton = findViewById<Button>(R.id.calculateButton)

        calculateButton.setOnClickListener {
            val hours = hoursEditText.text.toString().toIntOrNull() ?: 0
            val minutes = minutesEditText.text.toString().toIntOrNull() ?: 0

           if (hours == 0 && minutes == 0){
               val toast = Toast.makeText(this, R.string.app_name, Toast.LENGTH_SHORT)
               val inflater = layoutInflater
               val vw = inflater.inflate(R.layout.toast, null)
               toast.view = vw
               toast.show()
               return@setOnClickListener
           }

            val totalSeconds = (hours * 60 + minutes) * 60


            resultTextView.text = "Введенное время в секундах: $totalSeconds"
        }
        findViewById<Button>(R.id.settings_button).setOnClickListener { openSettings() }


        textItems = arrayOf(
            hoursEditText,
            minutesEditText,
            resultTextView,
            calculateButton,
            settingsButton,
        )
        applySettings()
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        val infoTextView = findViewById<TextView>(R.id.resultTextView)

        val hoursEditText = findViewById<EditText>(R.id.hoursEditText)
        val minutesEditText = findViewById<EditText>(R.id.minutesEditText)
        var hours = hoursEditText.text.toString().toIntOrNull() ?: 0
        var minutes = minutesEditText.text.toString().toIntOrNull() ?: 0

        return when (id) {
            R.id.action_plushour -> {
                hours += 1
                hoursEditText.setText(hours.toString())
                true
            }

            R.id.action_minushour -> {
                if (hours < 1) {
                    hours = 0
                } else {
                    hours -= 1
                }
                hoursEditText.setText(hours.toString())
                true
            }

            R.id.action_plusminute -> {
                minutes += 1
                minutesEditText.setText(minutes.toString())
                true
            }

            R.id.action_minusminute -> {
                if (minutes < 1)  {
                    minutes = 0
                } else {
                    minutes -= 1
                }
                minutesEditText.setText(minutes.toString())
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun openSettings() {
        val intent = Intent(this, SettingsActivity::class.java)
        startForResult.launch(intent)
    }

    private fun applySettings() {
        val backgroundColor = sharedPreferences.getInt("backgroundColor", Color.WHITE)
        val textColor = sharedPreferences.getInt("textColor", Color.BLACK)
        val font = sharedPreferences.getInt("font", 0)

        var mainLayout = findViewById<View>(R.id.main_layout)
        mainLayout.setBackgroundColor(backgroundColor)

        val fontsDict = arrayOf(
            android.graphics.Typeface.NORMAL,
            android.graphics.Typeface.BOLD,
            android.graphics.Typeface.ITALIC,
            android.graphics.Typeface.BOLD_ITALIC
        )
        Log.d("font", font.toString())
        for (item in textItems) {
            item.setTextColor(textColor)
            item.setTypeface(item.typeface, fontsDict[font])
        }
    }
}