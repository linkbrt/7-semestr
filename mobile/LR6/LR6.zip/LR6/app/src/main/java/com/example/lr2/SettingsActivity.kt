package com.example.lr2

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.GenericFontFamily
import androidx.compose.ui.text.font.SystemFontFamily
import kotlin.text.get


class SettingsActivity : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    private var textItems = arrayOf<TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(R.style.AppTheme)
        setContentView(R.layout.activity_settings)

        textItems = arrayOf(
            findViewById<TextView>(R.id.label_color),
            findViewById<TextView>(R.id.label_text_color),
            findViewById<TextView>(R.id.label_font),
            findViewById<TextView>(R.id.apply_button),
        )

        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE)

        val applyButton: Button = findViewById(R.id.apply_button)

        val colorSpinner = findViewById<Spinner>(R.id.color_spinner)
        val textColorSpinner = findViewById<Spinner>(R.id.text_color_spinner)
        val fontSpinner = findViewById<Spinner>(R.id.font_spinner)

        val colorTextItems = listOf("Белый", "Красный", "Синий")
        var colorIntItems = listOf(Color.WHITE, Color.RED, Color.BLUE)

        val textColorTextItems = listOf("Черный", "Красный", "Синий")
        var textColorIntItems = listOf(Color.BLACK, Color.RED, Color.BLUE)

        val fontTextItems = listOf(
            "Нормальный",
            "Жирный",
            "Курсив",
            "Жирный курсив"
        )

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, colorTextItems)
        adapter.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item)
        colorSpinner.adapter = adapter

        val textAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, textColorTextItems)
        textAdapter.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item)
        textColorSpinner.adapter = textAdapter

        val fontAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, fontTextItems)
        fontAdapter.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item)
        fontSpinner.adapter = fontAdapter

        val bgColor = sharedPreferences.getInt("backgroundColor", -1)
        val textColor = sharedPreferences.getInt("textColor", -16777216)

        colorSpinner.setSelection(colorIntItems.indexOf(bgColor))
        textColorSpinner.setSelection(textColorIntItems.indexOf(textColor))
        fontSpinner.setSelection(sharedPreferences.getInt("font", 0))

        applyButton.setOnClickListener {
            sharedPreferences.edit().putInt("backgroundColor", colorIntItems[colorTextItems.indexOf(colorSpinner.selectedItem)]).apply()
            sharedPreferences.edit().putInt("textColor", textColorIntItems[textColorTextItems.indexOf(textColorSpinner.selectedItem)]).apply()
            sharedPreferences.edit().putInt("font", fontSpinner.selectedItemPosition).apply()
            applySettings()
        }

        loadSettings()
    }

    private fun applySettings() {
        setResult(RESULT_OK)
        finish()
    }

    private fun loadSettings() {
        val backgroundColor = sharedPreferences.getInt("backgroundColor", Color.WHITE)
        val textColor = sharedPreferences.getInt("textColor", Color.BLACK)
        val font = sharedPreferences.getInt("font", 0)

        val fontsDict = arrayOf(
            android.graphics.Typeface.NORMAL,
            android.graphics.Typeface.BOLD,
            android.graphics.Typeface.ITALIC,
            android.graphics.Typeface.BOLD_ITALIC
        )

        findViewById<View>(R.id.settings_layout).setBackgroundColor(backgroundColor)
        for (item in textItems) {
            item.setTextColor(textColor)
            item.setTypeface(item.typeface, fontsDict[font])
        }
    }
}
