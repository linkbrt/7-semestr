package com.example.lr11

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var locationInput: EditText
    private lateinit var searchButton: Button
    private lateinit var streetViewButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        locationInput = findViewById(R.id.locationInput)
        searchButton = findViewById(R.id.searchButton)
        streetViewButton = findViewById(R.id.streetViewButton)

        searchButton.setOnClickListener {
            val query = locationInput.text.toString()
            if (query.isNotEmpty()) {
                openGoogleMaps(query)
            } else {
                Toast.makeText(this, "Введите адрес или координаты", Toast.LENGTH_SHORT).show()
            }
        }
        streetViewButton.setOnClickListener {
            val query = locationInput.text.toString()
            if (query.isNotEmpty()) {
                openStreetView(query)
            } else {
                Toast.makeText(this, "Введите координаты (широта, долгота)", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Метод для открытия Google Maps с адресом или координатами
    private fun openGoogleMaps(query: String) {
        try {
            if (query.contains(",")) {
                // Если введены координаты (широта, долгота)
                val coords = query.split(",")
                val latitude = coords[0].toDouble()
                val longitude = coords[1].toDouble()

                // Формируем URI для Google Maps с координатами
                val uri = Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                intent.setPackage("com.google.android.apps.maps")
                startActivity(intent)

            } else {
                // Если введен адрес
                val uri = Uri.parse("geo:0,0?q=$query")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                intent.setPackage("com.google.android.apps.maps")
                startActivity(intent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Ошибка при открытии карты", Toast.LENGTH_SHORT).show()
        }
    }
    private fun openStreetView(query: String) {
        try {
            if (query.contains(",")) {
                // Если введены координаты (широта, долгота)
                val coords = query.split(",")
                val latitude = coords[0].toDouble()
                val longitude = coords[1].toDouble()

                // Формируем URI для открытия Street View с координатами
                val uri = Uri.parse("google.streetview:cbll=$latitude,$longitude")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                intent.setPackage("com.google.android.apps.maps")
                startActivity(intent)

            } else {
                // Если введен адрес, можно использовать Geocoder для получения координат
                val uri = Uri.parse("geo:0,0?q=$query&mode=streetview")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                intent.setPackage("com.google.android.apps.maps")
                startActivity(intent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Ошибка при открытии панорамы улиц", Toast.LENGTH_SHORT).show()
        }
    }
}