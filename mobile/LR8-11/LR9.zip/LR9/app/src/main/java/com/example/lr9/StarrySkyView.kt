package com.example.lr9

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin
import kotlin.random.Random
import android.os.Handler
import android.os.Looper
import kotlin.math.cos

class StarrySkyView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val starPaint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val moonPaint = Paint().apply {
        color = Color.YELLOW
        style = Paint.Style.FILL
    }

    private val spaceshipBitmap = BitmapFactory.decodeResource(resources, R.drawable.spaceship)

    // Данные для звёзд
    private var stars = emptyList<Pair<PointF, Float>>() // Координаты и прозрачность
    private var isStarsInitialized = false
    private var starAlphaDirection = true

    // Данные для луны
    private var moonPhase = 0f
    private var phaseDirection = 1

    // Данные для корабля
    private var spaceshipX = 0f
    private var spaceshipY = 0f
    private var spaceshipAngle = 0f

    // Таймер для анимации
    private val handler = Handler(Looper.getMainLooper())
    private val updateInterval = 50L

    init {
        handler.post(object : Runnable {
            override fun run() {
                updateAnimation()
                invalidate()
                handler.postDelayed(this, updateInterval)
            }
        })
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)

        if (!isStarsInitialized) {
            initializeStars()
            isStarsInitialized = true
        }

        drawStars(canvas)
        drawMoon(canvas)
        drawSpaceship(canvas)
        drawClock(canvas)
    }

    private fun initializeStars() {
        stars = List(100) {
            Pair(
                PointF(Random.nextFloat() * width, Random.nextFloat() * height),
                Random.nextFloat()
            )
        }
    }

    private fun updateAnimation() {
        // Мерцание звёзд
        stars = stars.map { (point, alpha) ->
            val newAlpha = alpha + if (starAlphaDirection) 0.05f else -0.05f
            if (newAlpha <= 0f || newAlpha >= 1f) {
                starAlphaDirection = !starAlphaDirection
            }
            point to newAlpha.coerceIn(0f, 1f)
        }

        moonPhase += phaseDirection * 0.05f
        if (moonPhase >= 1f || moonPhase <= 0f) {
            phaseDirection *= -1
        }

        spaceshipAngle += 0.05f
        spaceshipX = (width / 2 + 200 * sin(spaceshipAngle)).toFloat()
        spaceshipY = (height / 2 + 100 * sin(spaceshipAngle * 2)).toFloat()
    }

    private fun drawStars(canvas: Canvas) {
        stars.forEach { (point, alpha) ->
            starPaint.alpha = (alpha * 255).toInt()
            canvas.drawCircle(point.x, point.y, 5f, starPaint)
        }
    }

    private fun drawMoon(canvas: Canvas) {
        val moonX = width - 200f
        val moonY = 200f
        val moonRadius = 100f
        canvas.drawCircle(moonX, moonY, moonRadius, moonPaint)

        val crescentPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.FILL
        }
        canvas.drawCircle(moonX + 30f * (1 - moonPhase), moonY, moonRadius, crescentPaint)
    }

    private fun drawSpaceship(canvas: Canvas) {
        canvas.drawBitmap(spaceshipBitmap, spaceshipX - spaceshipBitmap.width / 2, spaceshipY - spaceshipBitmap.height / 2, null)
    }

    private fun drawClock(canvas: Canvas) {
        val clockPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 8f
        }
        val radius = 150f
        val centerX = width / 2f
        val centerY = height - 300f

        canvas.drawCircle(centerX, centerY, radius, clockPaint)

        val hourAngle = Math.PI / 6 - Math.PI / 2
        val hourX = centerX + radius / 2 * cos(hourAngle)
        val hourY = centerY + radius / 2 * sin(hourAngle)
        canvas.drawLine(centerX, centerY, hourX.toFloat(), hourY.toFloat(), clockPaint)

        val minuteAngle = Math.PI / 30 - Math.PI / 2
        val minX = centerX + radius * cos(minuteAngle)
        val minY = centerY + radius * sin(minuteAngle)
        canvas.drawLine(centerX, centerY, minX.toFloat(), minY.toFloat(), clockPaint)

        val currentSecond = System.currentTimeMillis() / 1000 % 60
        if (currentSecond in 15..35) {
            val cuckooPaint = Paint().apply {
                color = Color.YELLOW
                textSize = 50f
            }
            canvas.drawText("КУКУшка!", centerX - 60, centerY - radius - 50, cuckooPaint)
        }
    }
}