package com.example.lr8

import android.app.*
import android.content.Context
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Build
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnNotification = findViewById<Button>(R.id.btnNotification)

        btnNotification.setOnClickListener {
            sendNotification()
        }
    }

    private fun sendNotification() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Настройка канала для уведомлений (для Android 8.0 и выше)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "default_channel",
                "Default Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        // Создание уведомления с кнопками
        val actionIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        val buttonAction = NotificationCompat.Action(
            0, "Открой меня", actionIntent
        )

        // Создание уведомления в стиле Inbox (со списком)
        val inboxStyle = NotificationCompat.InboxStyle()
            .setBigContentTitle("Important Messages")
            .addLine("Сообщение 1")
            .addLine("Сообщение 2")
            .addLine("Сообщение 3")

        // Создание уведомления с длинным текстом
        val longTextStyle = NotificationCompat.BigTextStyle()
            .bigText("Очень длинное сообщение для проверки работы уведомлений с множеством линий")

        // Изображение для уведомления
        val largeIcon = BitmapFactory.decodeResource(resources, R.drawable.notification_image)

        // Создание уведомления
        val notification = NotificationCompat.Builder(this, "default_channel")
            .setSmallIcon(R.drawable.notification_image)
            .setContentTitle("Простое уведомление")
            .setContentText("Уведомление")
            .setStyle(longTextStyle) // Можно менять стиль на longTextStyle для длинного текста
            .setLargeIcon(largeIcon) // Можно добавлять картинку
            .addAction(buttonAction) // Кнопка в уведомлении
            .addAction(buttonAction)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setDefaults(NotificationCompat.DEFAULT_ALL) // Включает вибрацию, звук, свет
            .setVibrate(longArrayOf(0, 500, 1000)) // Настройка вибрации
            .setLights(0xFF00FF00.toInt(), 300, 1000) // Настройка световой индикации (зеленый)
            .build()

        // Отправка уведомления
        notificationManager.notify(1, notification)
    }
}
