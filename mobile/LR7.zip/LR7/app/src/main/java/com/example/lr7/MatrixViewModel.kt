package com.example.lr7

import androidx.lifecycle.ViewModel

class MatrixViewModel : ViewModel() {

    var matrix: Array<Array<Int>> = arrayOf()

    fun initializeMatrix(rows: Int = 5, cols: Int = 5) {
        matrix = Array(rows) { Array(cols) { 0 } }
    }

    fun isMatrixInitialized(): Boolean {
        return matrix.isNotEmpty()
    }

    fun fillMatrixRandomly(rows: Int, cols: Int) {
        matrix = Array(rows) { Array(cols) { (-10..10).random() } }
    }

    // Метод для поиска столбца с равным количеством положительных и отрицательных элементов
    fun findColumnWithEqualPosNeg(): Int {
        for (col in matrix[0].indices) {
            var positiveCount = 0
            var negativeCount = 0

            for (row in matrix.indices) {
                when {
                    matrix[row][col] > 0 -> positiveCount++
                    matrix[row][col] < 0 -> negativeCount++
                }
            }

            if (positiveCount == negativeCount) {
                return col
            }
        }
        return -1
    }
}
