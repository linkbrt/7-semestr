package com.example.lr7

import android.os.Bundle
import androidx.activity.viewModels
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.example.lr7.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MatrixViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Отображение матрицы из ViewModel (если она уже была создана)
        if (viewModel.isMatrixInitialized()) {
            displayMatrix()
        }

        // Обработчик ручного ввода
        binding.btnManualInput.setOnClickListener {
            val rows = binding.etRows.text.toString().toInt()
            val cols = binding.etCols.text.toString().toInt()
            viewModel.initializeMatrix(rows, cols)
            displayMatrix()
        }

        // Обработчик случайного заполнения
        binding.btnRandomFill.setOnClickListener {
            val rows = binding.etRows.text.toString().toInt()
            val cols = binding.etCols.text.toString().toInt()
            viewModel.fillMatrixRandomly(rows, cols)
            displayMatrix()
        }

        // Поиск столбца с равным количеством положительных и отрицательных чисел
        binding.btnFindColumn?.setOnClickListener {
            val result = viewModel.findColumnWithEqualPosNeg()
            binding.tvResult?.text = if (result != -1) {
                "Столбец с равным количеством: $result"
            } else {
                "Такого столбца нет"
            }
        }
    }

    private fun displayMatrix() {
        val matrix = viewModel.matrix
        val builder = StringBuilder()
        matrix.forEach { row ->
            builder.append(row.joinToString(" ")).append("\n")
        }
        binding.tvMatrix.text = builder.toString()
    }
}
