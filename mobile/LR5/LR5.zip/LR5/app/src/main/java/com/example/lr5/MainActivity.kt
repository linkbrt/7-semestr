package com.example.lr5

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TableLayout
import android.widget.TableRow
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    private lateinit var gameTable: TableLayout
    private lateinit var buttons: Array<Button?>
    private val size = 4
    private var emptyIndex = size * size - 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gameTable = findViewById(R.id.game_table)
        buttons = arrayOfNulls(size * size)

        createButtons()
        shuffle()
        updateAvailableMoves()

        val resetButton: Button = findViewById(R.id.reset_button)
        resetButton.setOnClickListener { resetGame() }
    }

    private fun createButtons() {
        for (i in 0 until size) {
            val row = TableRow(this)
            for (j in 0 until size) {
                val index = i * size + j
                buttons[index] = Button(this).apply {
                    text = if (index == emptyIndex) "" else (index + 1).toString()
                    setOnClickListener { onButtonClick(index) }
                    layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f)
                    setBackgroundColor(Color.LTGRAY)
                }
                row.addView(buttons[index])
            }
            gameTable.addView(row)
        }
    }

    private fun shuffle() {
        val positions = (0 until size * size).shuffled()
        for (i in buttons.indices) {
            buttons[i]?.text = if (positions[i] == emptyIndex) "" else (positions[i] + 1).toString()
        }
        emptyIndex = positions.indexOf(emptyIndex)
    }

    private fun onButtonClick(index: Int) {
        if (isAdjacent(index, emptyIndex)) {
            swap(index, emptyIndex)
            emptyIndex = index
            updateAvailableMoves()
        }
    }

    private fun isAdjacent(index1: Int, index2: Int): Boolean {
        val row1 = index1 / size
        val col1 = index1 % size
        val row2 = index2 / size
        val col2 = index2 % size
        return (row1 == row2 && abs(col1 - col2) == 1) || (col1 == col2 && abs(row1 - row2) == 1)
    }

    private fun swap(index1: Int, index2: Int) {
        val tempText = buttons[index1]?.text
        buttons[index1]?.text = buttons[index2]?.text
        buttons[index2]?.text = tempText
    }

    private fun updateAvailableMoves() {
        for (i in buttons.indices) {
            if (buttons[i]?.text != "") {
                buttons[i]?.setBackgroundColor(Color.LTGRAY)
                if (isAdjacent(i, emptyIndex)) {
                    buttons[i]?.setBackgroundColor(Color.CYAN)
                }
            } else {
                buttons[i]?.setBackgroundColor(Color.TRANSPARENT)
            }
        }
    }

    private fun resetGame() {
        shuffle()
        updateAvailableMoves()
    }
}
