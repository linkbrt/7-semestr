import sys, random
from typing import List

from PySide6.QtCore import QSize
from PySide6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout
from PySide6.QtGui import QPalette, QColor
from PySide6 import QtWidgets as widgets

from services.agent import Agent, AgentFactory


class AgentCell(QWidget):
    def __init__(self, agent: Agent = None):
        super(AgentCell, self).__init__()
        self.setAutoFillBackground(True)
    
        self.agent = agent

        self.render()
    

    def setAgent(self, new_agent: Agent = None):
        self.agent = new_agent
    

    def render(self):
        palette = self.palette()
        palette.setColor(QPalette.Window, QColor(self.agent.color if self.agent else 'grey'))
        self.setPalette(palette)


    def mousePressEvent(self, event):
        if not self.agent:
            return window.agent_info_label.setText("Пустая клетка")
        window.agent_info_label.setText(self.agent.get_info())


class MainWindow(QMainWindow):
    def __init__(self, x: int, y: int, agents: list[Agent]):
        super(MainWindow, self).__init__()
        self.setWindowTitle("LR6")

        self.agents: list[Agent] = agents

        self.borderX = x
        self.borderY = y

        self.setMinimumSize(1200, 600)

        
        self.main_box = QHBoxLayout()
        self.left_menu = QVBoxLayout()


        self.timer_button = widgets.QPushButton()
        self.timer_button.mousePressEvent = lambda event: self.step()

        self.agent_info_label = widgets.QLabel("")

        self.main_box.addLayout(self.left_menu)

        self.left_menu.addWidget(self.timer_button)
        self.left_menu.addWidget(self.agent_info_label)
        
        self.gridLayout = QGridLayout()

        self.main_box.addLayout(self.gridLayout)

        widget = QWidget()
        widget.setLayout(self.main_box)
        self.setCentralWidget(widget)

        self.render()


    def render(self):
        for i in range(self.borderX):
            for j in range(self.borderY):
                cell = AgentCell()
                self.gridLayout.addWidget(cell, i, j)

        for agent in self.agents:
            self.gridLayout.addWidget(AgentCell(agent), agent.pos_x, agent.pos_y)
    
    def step(self):
        for agent in self.agents:
            agent.step()
        # self.render()
        for i in range(self.borderX):
            for j in range(self.borderY):
                self.gridLayout.itemAtPosition(i, j).widget().setAgent(None)


if __name__ == "__main__":
    app = QApplication([])

    grid_size = {'x': 30, 'y': 30}

    agents = AgentFactory.generate_agents(20, grid_size['x']-1, grid_size['y']-1)
    print(agents[0].pos_y)
    window = MainWindow(grid_size['x'], grid_size['y'], agents)

    window.show()

    sys.exit(app.exec())