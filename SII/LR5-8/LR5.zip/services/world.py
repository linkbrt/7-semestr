from .agent import Agent

import random


class World:
    size: tuple[int, int]
    agents = []
    def __init__(self, size):
        self.size = size


    def generate_population(self, agents):
        for _ in range(agents):
            agents.append(Agent(5, (random.randint(0, self.size), random.randint(0, self.size))))


world = World((50, 50))
world.generate_population(20)
print(world.agents)
