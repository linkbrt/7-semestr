from typing import List


class Neuron:
    def __init__(self):
        self.inputs = [1] * 12

    def activate(self):
        return sum(self.inputs)
    
    def __repr__(self):
        return " ".join(map(str, self.inputs))


class NeuroController:
    neurons: List[Neuron]

    def __init__(self):
        self.neurons = [Neuron() for _ in range(4)]
    
    def process(self):
        return [neuron.activate() for neuron in self.neurons]
