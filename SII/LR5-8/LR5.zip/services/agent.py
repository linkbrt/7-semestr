from enum import Enum
import random

from .network import NeuroController

class Direction(Enum):
    NORTH = 1
    WEST = 2
    EAST = 3
    SOUTH = 4


class Agent:
    color: str
    health: int
    pos_x: int
    pos_y: int
    direction: Direction
    brain: NeuroController


    def __init__(self, health, direction = Direction.NORTH, pos_x = 0, pos_y = 0):
        self.health = health
        self.direction = Direction.NORTH
        self.brain = NeuroController()
        self.pos_x = pos_x
        self.pos_y = pos_y


    def get_info(self) -> str:
        return f'Цвет: {self.color}\nHP: {self.health}\nПозиция: x:{self.pos_x} y:{self.pos_y}\nНаправление: {self.direction.name}\nНейроны: {self.brain.neurons}'


    def step(self):
        if self.direction == Direction.NORTH:
            self.pos_x -= 1
        
        if self.pos_x < 0:
            self.pos_x = 29
        elif self.pos_x > 29:
            self.pos_x = 0



class Hunter(Agent):
    color = "red"



class Animal(Agent):
    color = "blue"



class Plant(Agent):
    color = "green"



AGENT_TYPES = [Hunter, Animal, Plant]

class AgentFactory:
    def generate_agents(n: int, max_x, max_y) -> list[Agent]:
        agents = []
        for _ in range(n):
            agent_type: Agent = random.choice(AGENT_TYPES)
            agents.append(agent_type(
                health=5, 
                pos_x=random.randint(0, max_x), 
                pos_y=random.randint(0, max_y))
            )
        return agents
